"""Tests for DataPipeline. Author: Bob Martinez"""
import pytest, sys
sys.path.insert(0, "..")
from python_module.pipeline import DataPipeline, SensorReading

def make_reading(val, sid="s1"):
    return SensorReading(sid, 1000.0, val, "C")

def test_ingest_and_count():
    p = DataPipeline("test")
    p.ingest(make_reading(22.5))
    p.ingest(make_reading(23.1))
    assert p.count == 2

def test_invalid_rejected():
    p = DataPipeline("test")
    p.ingest(make_reading(-1000))
    assert p.count == 0
    assert len(p.errors) == 1

def test_clean_filters():
    p = DataPipeline("test")
    for v in [10, 20, 30, 200]:
        p.ingest(make_reading(v))
    p.clean(0, 100)
    assert p.count == 3

def test_mean():
    p = DataPipeline("test")
    for v in [1, 2, 3, 4, 5]:
        p.ingest(make_reading(v))
    assert p.mean() == 3.0
