"""
Data pipeline module for processing sensor readings.
Author: Alice Johnson
"""
from dataclasses import dataclass
from typing import List, Optional
import statistics


@dataclass
class SensorReading:
    sensor_id: str
    timestamp: float
    value: float
    unit: str


class DataPipeline:
    def __init__(self, source_id: str):
        self._source_id = source_id
        self._readings: List[SensorReading] = []
        self._errors: List[str] = []

    def ingest(self, reading: SensorReading):
        if reading.value < -999:
            self._errors.append(f"Invalid reading from {reading.sensor_id}")
            return
        self._readings.append(reading)

    def clean(self, min_val: float, max_val: float) -> "DataPipeline":
        self._readings = [r for r in self._readings if min_val <= r.value <= max_val]
        return self

    def mean(self) -> Optional[float]:
        if not self._readings:
            return None
        return statistics.mean(r.value for r in self._readings)

    def stddev(self) -> Optional[float]:
        if len(self._readings) < 2:
            return None
        return statistics.stdev(r.value for r in self._readings)

    def export(self) -> List[dict]:
        return [{"id": r.sensor_id, "ts": r.timestamp, "val": r.value} for r in self._readings]

    @property
    def count(self):
        return len(self._readings)

    @property
    def errors(self):
        return list(self._errors)
