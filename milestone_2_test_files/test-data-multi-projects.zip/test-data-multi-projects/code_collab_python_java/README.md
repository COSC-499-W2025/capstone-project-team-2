# Sensor Data Platform

A collaborative multi-language project combining a Python data pipeline with a Java processing engine.

## Contributors
- Alice Johnson
- Bob Martinez

## Architecture
- Python (`python_module/`) — ingestion, cleaning, statistics via `DataPipeline`
- Java (`java_module/`) — abstract `DataProcessor` with `TemperatureProcessor` subclass

## Requirements
- Python 3.10+ with pytest
- Java 11+
