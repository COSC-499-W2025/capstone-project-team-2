package com.example.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;

/**
 * Sensor data processing engine.
 * Author: Bob Martinez
 */
public abstract class DataProcessor {
    protected final String processorId;
    protected final List<Double> buffer;

    public DataProcessor(String processorId) {
        this.processorId = processorId;
        this.buffer = new ArrayList<>();
    }

    public void feed(double value) {
        if (!isValid(value)) return;
        buffer.add(value);
        onDataAdded(value);
    }

    protected abstract boolean isValid(double value);
    protected abstract void onDataAdded(double value);
    public abstract String getProcessorType();

    public OptionalDouble average() {
        return buffer.stream().mapToDouble(Double::doubleValue).average();
    }

    public int size() { return buffer.size(); }

    @Override
    public String toString() {
        return getProcessorType() + "[" + processorId + "] n=" + size();
    }
}
