package com.example.processor;

/**
 * Temperature-specific processor with threshold alerting.
 * Author: Bob Martinez
 */
public class TemperatureProcessor extends DataProcessor {
    private final double minTemp;
    private final double maxTemp;
    private int alertCount = 0;

    public TemperatureProcessor(String id, double minTemp, double maxTemp) {
        super(id);
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
    }

    @Override
    protected boolean isValid(double value) {
        return value > -273.15; // above absolute zero
    }

    @Override
    protected void onDataAdded(double value) {
        if (value < minTemp || value > maxTemp) {
            alertCount++;
            System.out.println("[ALERT] " + processorId + ": " + value + "°C out of range");
        }
    }

    @Override
    public String getProcessorType() { return "TemperatureProcessor"; }

    public int getAlertCount() { return alertCount; }
}
