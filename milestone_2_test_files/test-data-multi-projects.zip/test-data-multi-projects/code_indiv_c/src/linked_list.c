/* linked_list.c - Linked list implementation. Author: Alex Kim */
#include "linked_list.h"
#include <stdlib.h>
#include <stdio.h>

LinkedList* list_create(void) {
    LinkedList* list = (LinkedList*)malloc(sizeof(LinkedList));
    if (!list) return NULL;
    list->head = NULL;
    list->size = 0;
    return list;
}

void list_destroy(LinkedList* list) {
    if (!list) return;
    Node* current = list->head;
    while (current) {
        Node* next = current->next;
        free(current);
        current = next;
    }
    free(list);
}

int list_push_front(LinkedList* list, int value) {
    Node* node = (Node*)malloc(sizeof(Node));
    if (!node) return -1;
    node->data = value;
    node->next = list->head;
    list->head = node;
    list->size++;
    return 0;
}

int list_push_back(LinkedList* list, int value) {
    Node* node = (Node*)malloc(sizeof(Node));
    if (!node) return -1;
    node->data = value;
    node->next = NULL;
    if (!list->head) {
        list->head = node;
    } else {
        Node* cur = list->head;
        while (cur->next) cur = cur->next;
        cur->next = node;
    }
    list->size++;
    return 0;
}

int list_pop_front(LinkedList* list, int* out) {
    if (!list->head) return -1;
    Node* old = list->head;
    *out = old->data;
    list->head = old->next;
    free(old);
    list->size--;
    return 0;
}

int list_contains(const LinkedList* list, int value) {
    Node* cur = list->head;
    while (cur) {
        if (cur->data == value) return 1;
        cur = cur->next;
    }
    return 0;
}

void list_print(const LinkedList* list) {
    Node* cur = list->head;
    printf("[");
    while (cur) {
        printf("%d", cur->data);
        if (cur->next) printf(" -> ");
        cur = cur->next;
    }
    printf("]\n");
}

size_t list_size(const LinkedList* list) {
    return list ? list->size : 0;
}
