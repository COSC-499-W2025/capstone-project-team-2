/* main.c - Demo usage of linked list. Author: Alex Kim */
#include "linked_list.h"
#include <stdio.h>

int main(void) {
    LinkedList* list = list_create();
    list_push_back(list, 10);
    list_push_back(list, 20);
    list_push_front(list, 5);
    printf("List: "); list_print(list);
    printf("Size: %zu\n", list_size(list));
    printf("Contains 20: %d\n", list_contains(list, 20));
    int val;
    list_pop_front(list, &val);
    printf("Popped: %d\n", val);
    list_destroy(list);
    return 0;
}
