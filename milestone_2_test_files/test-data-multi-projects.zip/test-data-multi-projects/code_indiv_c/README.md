# Linked List in C

Author: Alex Kim

A singly linked list implementation in C demonstrating struct-based OOP patterns, dynamic memory management, and a clean header/implementation split.

## Files
- `include/linked_list.h` — public interface
- `src/linked_list.c` — implementation
- `src/main.c` — demo usage
