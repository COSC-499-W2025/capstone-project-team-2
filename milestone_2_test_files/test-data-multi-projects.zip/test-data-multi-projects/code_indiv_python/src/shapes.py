"""
Geometry library demonstrating OOP principles.
Author: Jordan Lee
"""
import math


class Shape:
    """Abstract base shape."""

    def __init__(self, color="white"):
        self._color = color  # encapsulation: private attribute

    def area(self):
        raise NotImplementedError("Subclasses must implement area()")

    def perimeter(self):
        raise NotImplementedError("Subclasses must implement perimeter()")

    def describe(self):
        return f"{self.__class__.__name__}(color={self._color}, area={self.area():.2f})"

    def __repr__(self):
        return self.describe()

    def __eq__(self, other):
        return isinstance(other, Shape) and self.area() == other.area()

    def __lt__(self, other):
        return self.area() < other.area()


class Circle(Shape):
    def __init__(self, radius, color="white"):
        super().__init__(color)
        self._radius = radius

    def area(self):
        return math.pi * self._radius ** 2

    def perimeter(self):
        return 2 * math.pi * self._radius

    @property
    def radius(self):
        return self._radius


class Rectangle(Shape):
    def __init__(self, width, height, color="white"):
        super().__init__(color)
        self._width = width
        self._height = height

    def area(self):
        return self._width * self._height

    def perimeter(self):
        return 2 * (self._width + self._height)


class Square(Rectangle):
    def __init__(self, side, color="white"):
        super().__init__(side, side, color)

    def describe(self):
        return f"Square(side={self._width}, area={self.area():.2f})"


class Triangle(Shape):
    def __init__(self, a, b, c, color="white"):
        super().__init__(color)
        self._sides = (a, b, c)

    def perimeter(self):
        return sum(self._sides)

    def area(self):
        s = self.perimeter() / 2
        a, b, c = self._sides
        return math.sqrt(s * (s - a) * (s - b) * (s - c))


class ShapeCollection:
    def __init__(self):
        self._shapes = []

    def add(self, shape: Shape):
        self._shapes.append(shape)

    def total_area(self):
        return sum(s.area() for s in self._shapes)

    def largest(self):
        return max(self._shapes) if self._shapes else None

    def sorted_by_area(self):
        return sorted(self._shapes)

    def filter_by_type(self, shape_type):
        return [s for s in self._shapes if isinstance(s, shape_type)]
