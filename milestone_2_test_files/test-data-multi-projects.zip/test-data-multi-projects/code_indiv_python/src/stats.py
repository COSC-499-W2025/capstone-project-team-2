"""
Statistics utilities module.
Author: Jordan Lee
"""
import math
from collections import Counter


class DataSet:
    def __init__(self, values=None):
        self._data = list(values or [])

    def add(self, value):
        self._data.append(value)

    def mean(self):
        if not self._data:
            raise ValueError("Empty dataset")
        return sum(self._data) / len(self._data)

    def variance(self):
        if len(self._data) < 2:
            raise ValueError("Need at least 2 values")
        m = self.mean()
        return sum((x - m) ** 2 for x in self._data) / (len(self._data) - 1)

    def std_dev(self):
        return math.sqrt(self.variance())

    def median(self):
        s = sorted(self._data)
        n = len(s)
        mid = n // 2
        return (s[mid - 1] + s[mid]) / 2 if n % 2 == 0 else s[mid]

    def mode(self):
        counts = Counter(self._data)
        max_count = max(counts.values())
        return [k for k, v in counts.items() if v == max_count]

    def __len__(self):
        return len(self._data)

    def __repr__(self):
        return f"DataSet(n={len(self._data)}, mean={self.mean():.2f})"
