"""Tests for shapes and stats. Author: Jordan Lee"""
import pytest, sys, math
sys.path.insert(0, "..")
from src.shapes import Circle, Rectangle, Square, Triangle, ShapeCollection
from src.stats import DataSet

def test_circle_area():
    assert round(Circle(5).area(), 4) == round(math.pi * 25, 4)

def test_square_is_rectangle():
    assert isinstance(Square(4), Rectangle)

def test_polymorphism():
    shapes = [Circle(3), Rectangle(2, 5), Square(4), Triangle(3, 4, 5)]
    col = ShapeCollection()
    for s in shapes: col.add(s)
    assert col.largest() == max(shapes)

def test_encapsulation():
    c = Circle(3, color="red")
    assert c._color == "red"
    assert c.radius == 3

def test_dataset_stats():
    ds = DataSet([2, 4, 4, 4, 5, 5, 7, 9])
    assert ds.mean() == 5.0
    assert round(ds.std_dev(), 4) == 2.0

def test_dataset_empty_raises():
    with pytest.raises(ValueError):
        DataSet().mean()
