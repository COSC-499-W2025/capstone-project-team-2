# Geometry Library

Author: Jordan Lee

A Python geometry library with OOP design, statistics utilities, and full test coverage.

## Features
- Shape hierarchy (Circle, Rectangle, Square, Triangle) with polymorphic area/perimeter
- Encapsulated data via private attributes
- ShapeCollection with sorting and filtering
- DataSet statistics: mean, variance, std_dev, median, mode
