# Evaluating Transformer Models for Low-Resource Language Translation

**Author:** Morgan Taylor
**Date:** October 2024
**Field:** Natural Language Processing

---

## Abstract

This paper evaluates the performance of multilingual transformer models on low-resource language translation tasks. We benchmarked mBERT, XLM-R, and mT5 on five African languages with fewer than 50,000 training pairs each. Results show that mT5 achieves a BLEU score of 34.2 on average, outperforming XLM-R (28.7) and mBERT (22.1) across all tested languages. Fine-tuning on as few as 5,000 domain-specific sentence pairs improved accuracy by 18% relative to zero-shot baselines, suggesting targeted fine-tuning is highly effective even under severe data constraints.

---

## 1. Introduction

Low-resource languages — those with limited digital text corpora — present a persistent challenge for neural machine translation (NMT). While large models like GPT-4 and PaLM have achieved near-human translation quality on high-resource language pairs, their performance degrades significantly on languages with fewer than 100,000 parallel sentences.

This work focuses on five languages: Amharic, Wolof, Kinyarwanda, Tigrinya, and Zarma. Together these represent over 80 million speakers whose access to multilingual NLP tools remains severely limited.

---

## 2. Methodology

### 2.1 Models Evaluated
- **mBERT** — 12-layer multilingual BERT pretrained on 104 languages
- **XLM-R** — RoBERTa-based, trained on 2.5TB of filtered CommonCrawl text across 100 languages
- **mT5** — T5 architecture scaled to 101 languages; 300M parameter base variant

### 2.2 Datasets
Training data sourced from JW300, CCAligned, and OPUS with manual quality filtering. Test sets of 2,000 sentence pairs per language were professionally translated to ensure reference quality.

### 2.3 Evaluation Metrics
- BLEU (primary)
- chrF++ (character-level F-score for morphologically rich languages)
- Human evaluation via 5-point fluency/adequacy scale (50 sentences per language, 3 annotators each)

---

## 3. Results

| Model | Avg BLEU | Amharic | Wolof | Kinyarwanda | Tigrinya | Zarma |
|---|---|---|---|---|---|---|
| mBERT | 22.1 | 19.4 | 21.8 | 24.5 | 23.2 | 21.6 |
| XLM-R | 28.7 | 26.1 | 27.9 | 31.4 | 29.8 | 28.3 |
| mT5 | 34.2 | 31.8 | 33.5 | 37.1 | 35.4 | 33.2 |

Human evaluators rated mT5 outputs 3.8/5.0 on fluency and 3.6/5.0 on adequacy, compared to 2.9/5.0 and 2.7/5.0 for XLM-R respectively.

---

## 4. Discussion

The 54.8% improvement of mT5 over mBERT aligns with findings from Xue et al. (2021), who similarly found encoder-decoder architectures superior for generation tasks. The impact of domain-specific fine-tuning was most pronounced for Amharic (+23% BLEU) and least for Wolof (+12%), likely reflecting differences in morphological complexity.

---

## 5. Conclusion

mT5 fine-tuned on small domain-specific corpora delivers usable translation quality for low-resource African languages. With 5,000 sentence pairs and 3 hours of fine-tuning on a single A100 GPU, practitioners can achieve results previously requiring 10x more data. Future work will explore data augmentation via back-translation and retrieval-augmented generation.

---

## References

1. Xue et al. (2021). mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer. NAACL.
2. Conneau et al. (2020). Unsupervised Cross-lingual Representation Learning at Scale. ACL.
3. Adelani et al. (2022). MasakhaNER 2.0: Africa-centric Transfer Learning for Named Entity Recognition. EMNLP.
