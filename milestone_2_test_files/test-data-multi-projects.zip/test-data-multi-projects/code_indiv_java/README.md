# Animal Shelter

Author: Sam Rivera

Java OOP project demonstrating inheritance, polymorphism, and encapsulation through an animal shelter management system.

## Classes
- `Animal` — abstract base with encapsulated name/age fields
- `Dog`, `Cat` — concrete subclasses overriding `speak()` and `getType()`
- `Shelter` — collection manager with stream-based filtering
