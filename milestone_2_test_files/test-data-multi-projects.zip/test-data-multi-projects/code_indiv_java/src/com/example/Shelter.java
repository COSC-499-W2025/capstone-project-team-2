package com.example;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Animal shelter managing a collection of animals.
 * Author: Sam Rivera
 */
public class Shelter {
    private String name;
    private List<Animal> animals;

    public Shelter(String name) {
        this.name = name;
        this.animals = new ArrayList<>();
    }

    public void admit(Animal a) { animals.add(a); }

    public List<Animal> getAll() { return new ArrayList<>(animals); }

    public List<Animal> getDogs() {
        return animals.stream()
            .filter(a -> a instanceof Dog)
            .collect(Collectors.toList());
    }

    public int count() { return animals.size(); }

    public void printAll() {
        System.out.println("=== " + name + " ===");
        animals.forEach(a -> System.out.println("  " + a.describe()));
    }
}
