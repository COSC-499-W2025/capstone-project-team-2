package com.example;

/** Author: Sam Rivera */
public class Dog extends Animal {
    private String breed;

    public Dog(String name, int age, String breed) {
        super(name, age);
        this.breed = breed;
    }

    @Override
    public String speak() { return "Woof!"; }

    @Override
    public String getType() { return "Dog"; }

    public String getBreed() { return breed; }
}
