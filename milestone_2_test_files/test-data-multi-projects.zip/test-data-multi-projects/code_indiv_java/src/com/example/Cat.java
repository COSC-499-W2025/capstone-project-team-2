package com.example;

/** Author: Sam Rivera */
public class Cat extends Animal {
    private boolean isIndoor;

    public Cat(String name, int age, boolean isIndoor) {
        super(name, age);
        this.isIndoor = isIndoor;
    }

    @Override
    public String speak() { return "Meow!"; }

    @Override
    public String getType() { return "Cat"; }

    public boolean isIndoor() { return isIndoor; }
}
