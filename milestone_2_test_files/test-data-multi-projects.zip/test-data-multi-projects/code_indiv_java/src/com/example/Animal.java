package com.example;

/**
 * Abstract base class for animals.
 * Author: Sam Rivera
 */
public abstract class Animal {
    private String name;
    private int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() { return name; }
    public int getAge() { return age; }

    public abstract String speak();
    public abstract String getType();

    public String describe() {
        return getType() + " named " + name + " (age " + age + "): " + speak();
    }

    @Override
    public String toString() {
        return describe();
    }
}
