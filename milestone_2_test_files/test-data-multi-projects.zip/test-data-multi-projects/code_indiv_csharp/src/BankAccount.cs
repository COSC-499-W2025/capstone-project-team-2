// BankAccount.cs — Author: Casey Park
using System;
using System.Collections.Generic;

namespace BankingApp
{
    public abstract class BankAccount
    {
        private decimal _balance;
        protected string _owner;
        private List<string> _transactionLog;

        public BankAccount(string owner, decimal initialBalance = 0)
        {
            _owner = owner;
            _balance = initialBalance;
            _transactionLog = new List<string>();
        }

        public decimal Balance => _balance;
        public string Owner => _owner;

        protected void Credit(decimal amount)
        {
            if (amount <= 0) throw new ArgumentException("Amount must be positive");
            _balance += amount;
            _transactionLog.Add($"+{amount:C} [{DateTime.Now:s}]");
        }

        protected void Debit(decimal amount)
        {
            if (amount <= 0) throw new ArgumentException("Amount must be positive");
            if (amount > _balance) throw new InvalidOperationException("Insufficient funds");
            _balance -= amount;
            _transactionLog.Add($"-{amount:C} [{DateTime.Now:s}]");
        }

        public abstract void Deposit(decimal amount);
        public abstract void Withdraw(decimal amount);
        public abstract string AccountType { get; }

        public IReadOnlyList<string> GetHistory() => _transactionLog.AsReadOnly();

        public override string ToString() =>
            $"{AccountType} [{_owner}]: {_balance:C}";
    }

    public class SavingsAccount : BankAccount
    {
        private decimal _interestRate;

        public SavingsAccount(string owner, decimal rate = 0.03m)
            : base(owner) { _interestRate = rate; }

        public override void Deposit(decimal amount) => Credit(amount);
        public override void Withdraw(decimal amount) => Debit(amount);
        public override string AccountType => "Savings";

        public void ApplyInterest()
        {
            decimal interest = Balance * _interestRate;
            Credit(interest);
        }
    }

    public class CheckingAccount : BankAccount
    {
        private decimal _overdraftLimit;

        public CheckingAccount(string owner, decimal overdraft = 100m)
            : base(owner) { _overdraftLimit = overdraft; }

        public override void Deposit(decimal amount) => Credit(amount);

        public override void Withdraw(decimal amount)
        {
            if (amount > Balance + _overdraftLimit)
                throw new InvalidOperationException("Exceeds overdraft limit");
            Debit(Math.Min(amount, Balance));
        }

        public override string AccountType => "Checking";
    }
}
