# Banking App (C#)

Author: Casey Park

C# project demonstrating abstract base classes, encapsulation with private fields, properties, and polymorphic withdrawal/deposit behavior.

## Classes
- `BankAccount` — abstract base with private balance, protected helpers, transaction log
- `SavingsAccount` — adds interest calculation
- `CheckingAccount` — adds overdraft handling
