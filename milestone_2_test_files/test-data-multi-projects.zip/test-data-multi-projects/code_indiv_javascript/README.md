# Item API (JavaScript/Express)

Author: Riley Chen

Node.js REST API using Express with an OOP store class, full CRUD routes, and Jest unit tests.
