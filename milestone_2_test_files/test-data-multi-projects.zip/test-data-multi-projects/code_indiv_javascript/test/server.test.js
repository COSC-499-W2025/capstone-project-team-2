// test/server.test.js — Author: Riley Chen
const { store } = require('../src/server');

test('add and retrieve item', () => {
  store.items = []; store.nextId = 1;
  const item = store.add('Widget', 10);
  expect(item.name).toBe('Widget');
  expect(store.getAll().length).toBe(1);
});

test('remove item', () => {
  store.items = []; store.nextId = 1;
  const item = store.add('Gadget', 5);
  expect(store.remove(item.id)).toBe(true);
  expect(store.getAll().length).toBe(0);
});

test('getById returns null for missing', () => {
  expect(store.getById(9999)).toBeNull();
});
