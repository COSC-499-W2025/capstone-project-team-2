// server.js — Simple Express REST API. Author: Riley Chen
const express = require('express');
const app = express();
app.use(express.json());

const items = [];

class ItemStore {
  constructor() { this.items = []; this.nextId = 1; }
  add(name, qty) {
    const item = { id: this.nextId++, name, qty };
    this.items.push(item);
    return item;
  }
  getAll() { return [...this.items]; }
  getById(id) { return this.items.find(i => i.id === id) || null; }
  remove(id) {
    const idx = this.items.findIndex(i => i.id === id);
    if (idx === -1) return false;
    this.items.splice(idx, 1);
    return true;
  }
}

const store = new ItemStore();

app.get('/items', (req, res) => res.json(store.getAll()));
app.post('/items', (req, res) => {
  const { name, qty } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  res.status(201).json(store.add(name, qty || 0));
});
app.delete('/items/:id', (req, res) => {
  const removed = store.remove(parseInt(req.params.id));
  res.status(removed ? 204 : 404).send();
});

module.exports = { app, store };
if (require.main === module) app.listen(3000, () => console.log('Running on :3000'));
