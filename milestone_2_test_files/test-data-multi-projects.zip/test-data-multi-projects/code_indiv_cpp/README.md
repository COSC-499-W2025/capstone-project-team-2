# Particle Simulation (C++)

Author: Morgan Taylor

C++ project using operator overloading, encapsulation, and composition to build a 2D particle physics simulator.

## Classes
- `Vec2D` — 2D math vector with operator overloading (+, -, *, ==, <<)
- `Particle` — encapsulates position, velocity, mass with physics update
- `ParticleSystem` — collection with gravity and timestep simulation
