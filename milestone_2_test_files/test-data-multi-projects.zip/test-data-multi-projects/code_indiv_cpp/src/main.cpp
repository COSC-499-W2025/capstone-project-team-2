// main.cpp - Demo. Author: Morgan Taylor
#include "vec2d.hpp"
#include "particle.hpp"
#include <iostream>

int main() {
    ParticleSystem sys;
    sys.add(Particle(Vec2D(0, 10), Vec2D(1, 0), 1.0, "ball"));
    sys.add(Particle(Vec2D(5, 5),  Vec2D(-1, 2), 2.0, "rock"));
    sys.applyGravity();
    for (int i = 0; i < 5; ++i) sys.update(0.1);
    for (const auto& p : sys.particles())
        std::cout << p.tag() << " at " << p.position() << "\n";
    return 0;
}
