# Design Notes

Author: Bob Martinez

## Architecture Decisions

- In-memory store for simplicity in v1; swap for SQLite in v2
- TaskManager owns all task state — no global mutable state
- IDs are sequential integers; will migrate to UUID in v3
- Priority field added (high / medium / low) as of sprint 2

## Resolved Questions

- Completed tasks are NOT deletable (keep audit trail)
- Pagination deferred to v2
- Due dates added to backlog for next sprint

## Changelog

### Sprint 2 (current)
- Added priority field to TaskManager
- Implemented get_pending_tasks() and get_by_priority()
- Carol added utils/helpers.py with CSV export
- Alice built out Flask REST API in app/api.py

### Sprint 1
- Initial TaskManager with add/complete/list
- Database abstraction layer
- Basic test suite
