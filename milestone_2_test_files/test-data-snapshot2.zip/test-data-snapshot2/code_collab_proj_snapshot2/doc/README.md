# Code Collab Project

A collaborative task management system with REST API.

## Features
- Add, complete, and filter tasks by priority
- REST API via Flask
- Persistent in-memory store

## API Endpoints
- GET /tasks - list all tasks
- POST /tasks - create a task
- PATCH /tasks/<id>/complete - mark as done

## Contributors
- Alice
- Bob
- Carol
