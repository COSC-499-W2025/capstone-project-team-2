"""
Simple in-memory database abstraction.
Author: Alice Johnson
"""


class Database:
    def __init__(self):
        self._store = {}

    def save(self, key, value):
        self._store[key] = value

    def get(self, key):
        return self._store.get(key)

    def delete(self, key):
        if key in self._store:
            del self._store[key]

    def all(self):
        return dict(self._store)
