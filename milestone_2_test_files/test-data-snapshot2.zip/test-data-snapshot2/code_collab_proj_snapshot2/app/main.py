"""
Task management core module.
Author: Alice Johnson
"""


class TaskManager:
    def __init__(self):
        self.tasks = []

    def add_task(self, title, description, priority="medium"):
        task = {
            "id": len(self.tasks) + 1,
            "title": title,
            "description": description,
            "done": False,
            "priority": priority
        }
        self.tasks.append(task)
        return task

    def complete_task(self, task_id):
        for task in self.tasks:
            if task["id"] == task_id:
                task["done"] = True
                return task
        raise ValueError(f"Task {task_id} not found")

    def get_all_tasks(self):
        return self.tasks

    def get_pending_tasks(self):
        return [t for t in self.tasks if not t["done"]]

    def get_by_priority(self, priority):
        return [t for t in self.tasks if t["priority"] == priority]


if __name__ == "__main__":
    manager = TaskManager()
    manager.add_task("Design DB schema", "Plan the database layout", priority="high")
    manager.add_task("Build API", "Implement REST endpoints", priority="medium")
    print(manager.get_pending_tasks())
