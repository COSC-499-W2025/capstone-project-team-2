"""
Flask REST API for task management.
Author: Alice Johnson
"""
from flask import Flask, jsonify, request
from main import TaskManager

app = Flask(__name__)
manager = TaskManager()


@app.route("/tasks", methods=["GET"])
def list_tasks():
    return jsonify(manager.get_all_tasks())


@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.json
    task = manager.add_task(
        data["title"],
        data.get("description", ""),
        data.get("priority", "medium")
    )
    return jsonify(task), 201


@app.route("/tasks/<int:task_id>/complete", methods=["PATCH"])
def complete_task(task_id):
    try:
        task = manager.complete_task(task_id)
        return jsonify(task)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404


if __name__ == "__main__":
    app.run(debug=True)
