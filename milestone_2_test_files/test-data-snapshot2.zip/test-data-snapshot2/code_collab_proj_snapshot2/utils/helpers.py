"""
Utility helpers for task data.
Author: Carol Nguyen
"""


def format_task(task):
    status = "done" if task["done"] else "pending"
    return f"[{status}] [{task['priority'].upper()}] {task['title']}: {task['description']}"


def filter_tasks_by_status(tasks, done=False):
    return [t for t in tasks if t["done"] == done]


def sort_tasks_by_priority(tasks):
    priority_order = {"high": 0, "medium": 1, "low": 2}
    return sorted(tasks, key=lambda t: priority_order.get(t.get("priority", "medium"), 1))


def export_to_csv(tasks):
    if not tasks:
        return ""
    headers = list(tasks[0].keys())
    lines = [",".join(str(h) for h in headers)]
    for task in tasks:
        lines.append(",".join(str(task.get(h, "")) for h in headers))
    return "\n".join(lines)
