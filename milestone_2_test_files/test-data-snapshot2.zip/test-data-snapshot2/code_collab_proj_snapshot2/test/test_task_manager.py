"""
Unit tests for TaskManager - expanded suite.
Author: Bob Martinez
"""
import sys
import pytest
sys.path.insert(0, "..")
from app.main import TaskManager


def test_add_task():
    mgr = TaskManager()
    task = mgr.add_task("Test Task", "A description")
    assert task["title"] == "Test Task"
    assert task["done"] == False
    assert task["priority"] == "medium"


def test_add_task_with_priority():
    mgr = TaskManager()
    task = mgr.add_task("Urgent", "desc", priority="high")
    assert task["priority"] == "high"


def test_complete_task():
    mgr = TaskManager()
    mgr.add_task("Do thing", "desc")
    result = mgr.complete_task(1)
    assert result["done"] == True


def test_complete_missing_task_raises():
    mgr = TaskManager()
    with pytest.raises(ValueError):
        mgr.complete_task(999)


def test_get_all_tasks():
    mgr = TaskManager()
    mgr.add_task("A", "a")
    mgr.add_task("B", "b")
    assert len(mgr.get_all_tasks()) == 2


def test_get_pending_tasks():
    mgr = TaskManager()
    mgr.add_task("A", "a")
    mgr.add_task("B", "b")
    mgr.complete_task(1)
    pending = mgr.get_pending_tasks()
    assert len(pending) == 1
    assert pending[0]["title"] == "B"


def test_get_by_priority():
    mgr = TaskManager()
    mgr.add_task("High task", "desc", priority="high")
    mgr.add_task("Low task", "desc", priority="low")
    assert len(mgr.get_by_priority("high")) == 1
