# Design Notes

Author: Bob Martinez

## Architecture Decisions

- In-memory store for simplicity in v1; swap for SQLite in v2
- TaskManager owns all task state — no global mutable state
- IDs are sequential integers for now

## Open Questions

- Should completed tasks be deletable?
- Pagination needed once task list grows?
- Add due dates in next sprint?

## Planned Features

- Priority field (high / medium / low)
- REST API layer (Flask)
- Export to CSV
