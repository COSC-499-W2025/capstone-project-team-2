# Code Collab Project

A collaborative task management system.

## Features
- Add and complete tasks
- Persistent in-memory store

## Contributors
- Alice
- Bob
