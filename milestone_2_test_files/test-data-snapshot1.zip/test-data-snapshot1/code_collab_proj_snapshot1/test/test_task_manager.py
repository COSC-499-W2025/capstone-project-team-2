"""
Unit tests for TaskManager.
Author: Bob Martinez
"""
import sys
sys.path.insert(0, "..")
from app.main import TaskManager


def test_add_task():
    mgr = TaskManager()
    task = mgr.add_task("Test Task", "A description")
    assert task["title"] == "Test Task"
    assert task["done"] == False


def test_complete_task():
    mgr = TaskManager()
    mgr.add_task("Do thing", "desc")
    result = mgr.complete_task(1)
    assert result["done"] == True


def test_complete_missing_task_returns_none():
    mgr = TaskManager()
    result = mgr.complete_task(999)
    assert result is None


def test_get_all_tasks():
    mgr = TaskManager()
    mgr.add_task("A", "a")
    mgr.add_task("B", "b")
    assert len(mgr.get_all_tasks()) == 2
