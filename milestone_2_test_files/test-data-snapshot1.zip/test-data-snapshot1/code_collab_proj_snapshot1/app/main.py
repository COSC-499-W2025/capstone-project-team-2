"""
Task management core module.
Author: Alice Johnson
"""


class TaskManager:
    def __init__(self):
        self.tasks = []

    def add_task(self, title, description):
        task = {
            "id": len(self.tasks) + 1,
            "title": title,
            "description": description,
            "done": False
        }
        self.tasks.append(task)
        return task

    def complete_task(self, task_id):
        for task in self.tasks:
            if task["id"] == task_id:
                task["done"] = True
                return task
        return None

    def get_all_tasks(self):
        return self.tasks


if __name__ == "__main__":
    manager = TaskManager()
    manager.add_task("Design DB schema", "Plan the database layout")
    manager.add_task("Build API", "Implement REST endpoints")
    print(manager.get_all_tasks())
